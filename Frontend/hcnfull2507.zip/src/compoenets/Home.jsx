import React from 'react';



function Home() {
  const path = "src/assets/Images/";



  return (


    <>
      <h1>i am home</h1>

    </>
  );
}

export default Home;
