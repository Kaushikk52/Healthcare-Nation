import React from 'react'
import { Navigation, Pagination, Autoplay, A11y } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';

import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/scrollbar';
import 'swiper/swiper-bundle.css';
import '../App.css'
// import myimg from './Nirav_Vadhiya_img.jpeg'




const data = [
    {
        id: 1,
        username: "Nirav",
        marks: 625,
        img:'services-hospitals.png'
    },
    {
        id: 2,
        username: "Raj",
        marks: 825,
         img:'DialysisCenter-services.png'
    },
    {
        id: 3,
        username: "kamlesh",
        marks: 225,
         img:'BloodBank-services.png'
    },
    {
        id: 4,
        username: "Nirav4",
        marks: 258,
         img:'Clinics-services.png'
    },
    {
        id: 5,
        username: "Nirav5",
        marks: 285,
         img:'services-hospitals.png'
    },
    {
        id: 6,
        username: "Nirav6",
        marks: 250,
         img:'DialysisCenter-services.png'
    },


]



function Home1() {
  const path = "src/assets/Images/";


    return (
        <div className='container margin-top3'>
             <p className="semi-head">Services</p>
            <Swiper
                    modules={[Navigation, Pagination, Autoplay, A11y]}
                    spaceBetween={20}
                    slidesPerView={4}
                    loop={true}
                    // centeredSlides={true}
                    // grabCursor={true}
                    pagination={{ clickable: true, dynamicBullets: true }}
                    navigation
                    // ={{
                    //   nextEl: '.swiper-button-next',
                    // }}
                    autoplay={{ delay: 3000 }}
                    breakpoints={{
                      0: {
                        slidesPerView: 1,
                      },
                      520: {
                        slidesPerView: 2,
                      },
                      768: {
                        slidesPerView: 3,
                      },
                      1000: {
                        slidesPerView: 4,
                      },
                    }}
                // pagination={{ clickable: true }}
                // scrollbar={{ draggable: true }}
                // onSlideChange={() => console.log('slide change')}
                onSwiper={(swiper) => console.log(swiper)}
            >


                {
                    data.map(user => (
                        <SwiperSlide key={user.id} className='slide'>
                            <div className="slide-content">
                                <div className="user-image">
                                    <img src={path+user.img} alt="" className='my-img img-fluid' />
                                    </div>
                                    <div className="semi-head1">Home Care </div>

                              
                            </div>
                        </SwiperSlide>
                    ))
                }
            </Swiper>


            <div className="demo"></div>
        </div>
    )
}

export default Home1
