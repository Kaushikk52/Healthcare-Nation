import './App.css'
import MyNav from './compoenets/MyNav'
import  Carousel  from './compoenets/Carousel';
import Home1 from './compoenets/Home1';


function App() {

  return (
    <>
    <MyNav/>
    <Carousel/>
    <Home1/>

    </>
  )
}

export default App
